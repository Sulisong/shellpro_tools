Modulea = 1873.8086956522
Moduleb = 3989.5652173913
Modulec = 58.947826086956
Moduled = 56.626086956522
Modulew = 2002.0
Moduleh = 4144.0
Moduletype = 1
ModuleFillet = 50