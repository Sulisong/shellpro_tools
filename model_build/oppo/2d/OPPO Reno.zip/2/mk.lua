Modulea = 1011.7577639752
Moduleb = 2168.2633540373
Modulec = 34.905590062112
Moduled = 158.04099378882
Modulew = 1086.0
Moduleh = 2378.0
Moduletype = 1
ModuleFillet = 50