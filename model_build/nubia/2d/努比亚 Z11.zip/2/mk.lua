Modulea = 895.45454545455
Moduleb = 1586.6028708134
Modulec = 90.0
Moduled = 165.74162679426
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1