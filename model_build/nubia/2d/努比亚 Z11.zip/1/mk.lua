Modulea = 893.18181818182
Moduleb = 1588.5167464115
Modulec = 91.136363636364
Moduled = 165.74162679426
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1