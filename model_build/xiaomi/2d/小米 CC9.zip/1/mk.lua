Modulea=828.0
Moduleb=1785.6
Modulec=49.2
Moduled=56.4
Modulew=924
Moduleh=1932
Moduletype=1
ModuleFillet = nil