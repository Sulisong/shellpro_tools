Modulea = 1154.5454545455
Moduleb = 2041.4673046252
Modulec = 139.69696969697
Moduled = 222.26475279107
Modulew = 1440.0
Moduleh = 2560.0
Moduletype = 1