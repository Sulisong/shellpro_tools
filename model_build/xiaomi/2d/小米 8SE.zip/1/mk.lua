Modulea=895.89130434783
Moduleb=1838.8695652174
Modulec=55.434782608696
Moduled=64.434782608696
Modulew=1008
Moduleh=1995
Moduletype=1
ModuleFillet = nil