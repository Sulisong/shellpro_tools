Modulea = 948.75
Moduleb = 1885.2631578947
Modulec = 68.75
Moduled = 136.18421052632
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1