Modulea = 930.9068923821
Moduleb = 2038.6577992745
Modulec = 71.717049576784
Moduled = 137.23095525998
Modulew = 1080.0
Moduleh = 2340.0
Moduletype = 1