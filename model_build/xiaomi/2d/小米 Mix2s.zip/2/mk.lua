Modulea=1084.8869565217
Moduleb=2165.4285714286
Modulec=31.486956521739
Moduled=36.211180124224
Modulew=1158
Moduleh=2332
Moduletype=1
ModuleFillet = nil