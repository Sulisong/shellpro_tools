Modulea=1081.9900621118
Moduleb=2165.4285714286
Modulec=32.935403726708
Moduled=37.659627329193
Modulew=1158
Moduleh=2332
Moduletype=1
ModuleFillet = nil