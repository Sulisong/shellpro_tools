Modulea = 575.0
Moduleb = 1157.0
Modulec = 462.0
Moduled = 206.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2