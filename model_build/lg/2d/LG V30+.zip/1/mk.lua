Modulea = 1243.9393939394
Moduleb = 2478.9473684211
Modulec = 98.787878787879
Moduled = 176.84210526316
Modulew = 1440.0
Moduleh = 2880.0
Moduletype = 1