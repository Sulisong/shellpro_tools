Modulea=1024.4906832298
Moduleb=1812.4546583851
Modulec=26.442236024845
Moduled=203.52298136646
Modulew=1076
Moduleh=2214
Moduletype=1
ModuleFillet = nil