Modulea = 1316.6666666667
Moduleb = 2650.0438596491
Modulec = 65.0
Moduled = 170.39473684211
Modulew = 1440.0
Moduleh = 2960.0
Moduletype = 1