Modulea = 1310.6060606061
Moduleb = 2695.3349282297
Modulec = 63.939393939394
Moduled = 140.44657097289
Modulew = 1440.0
Moduleh = 2960.0
Moduletype = 1