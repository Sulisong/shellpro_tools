Modulea=778.47453416149
Moduleb=1378.9217391304
Modulec=34.736024844721
Moduled=163.27950310559
Modulew=849
Moduleh=1696
Moduletype=1
ModuleFillet = nil