Modulea = 1296.9696969697
Moduleb = 2666.3825757576
Modulec = 71.515151515152
Moduled = 153.81628787879
Modulew = 1440.0
Moduleh = 2960.0
Moduletype = 1