Modulea = 921.33333333333
Moduleb = 1912.0
Modulec = 89.333333333333
Moduled = 128.0
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1