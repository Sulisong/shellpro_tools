Modulea = 768.18181818182
Moduleb = 1362.5
Modulec = 154.77272727273
Moduled = 278.18181818182
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1