Modulea = 1027.1440993789
Moduleb = 2120.0590062112
Modulec = 30.427950310559
Moduled = 57.374534161491
Modulew = 1088.0
Moduleh = 2253.0
Moduletype = 1
ModuleFillet = 40