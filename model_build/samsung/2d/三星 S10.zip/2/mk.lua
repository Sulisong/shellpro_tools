Modulea = 569.51552795031
Moduleb = 1183.3043478261
Modulec = 496.73291925466
Moduled = 214.32298136646
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2
ModuleFillet = 40