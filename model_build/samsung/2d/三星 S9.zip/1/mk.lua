Modulea=1562.8826086957
Moduleb=3205.1217391304
Modulec=44.95652173913
Moduled=191.77826086957
Modulew=1655
Moduleh=3549
Moduletype=1
ModuleFillet = nil