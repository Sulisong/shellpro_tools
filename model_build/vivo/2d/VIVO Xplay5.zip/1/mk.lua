Modulea = 819.77777777778
Moduleb = 1438.6296296296
Modulec = 55.111111111111
Moduled = 184.16666666667
Modulew = 930.0
Moduleh = 1815.0
Moduletype = 1