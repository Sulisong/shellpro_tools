Modulea = 1194.8931677019
Moduleb = 2588.5788819876
Modulec = 54.430434782609
Moduled = 45.413664596273
Modulew = 1308.0
Moduleh = 2708.0
Moduletype = 1