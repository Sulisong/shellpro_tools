Modulea = 868.75
Moduleb = 1541.25
Modulec = 105.0
Moduled = 182.5
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1