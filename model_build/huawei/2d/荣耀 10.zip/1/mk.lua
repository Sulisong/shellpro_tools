Modulea = 585.0
Moduleb = 1232.0
Modulec = 458.0
Moduled = 169.958
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2