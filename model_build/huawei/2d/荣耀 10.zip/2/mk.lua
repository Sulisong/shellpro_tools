Modulea = 578.0
Moduleb = 1212.0
Modulec = 455.0
Moduled = 175.958
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2