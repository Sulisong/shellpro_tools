Modulea = 955.68181818182
Moduleb = 1900.1196172249
Modulec = 60.454545454545
Moduled = 113.25358851675
Modulew = 1080.0
Moduleh = 2160
Moduletype = 1