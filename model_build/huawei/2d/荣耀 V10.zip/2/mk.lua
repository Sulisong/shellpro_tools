Modulea = 581.0
Moduleb = 1151.0
Modulec = 461.0
Moduled = 225.958
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2