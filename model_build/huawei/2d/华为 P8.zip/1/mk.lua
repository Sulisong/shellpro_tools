Modulea=1083.7267080745
Moduleb=1924.4720496894
Modulec=57.391304347826
Moduled=228.07453416149
Modulew=1200
Moduleh=2400
Moduletype=1
ModuleFillet = nil