Modulea=1082.2360248447
Moduleb=1921.4906832298
Modulec=58.88198757764
Moduled=248.94409937888
Modulew=1200
Moduleh=2400
Moduletype=1
ModuleFillet = nil