Modulea = 855.68181818182
Moduleb = 1517.7033492823
Modulec = 111.59090909091
Moduled = 193.49282296651
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1