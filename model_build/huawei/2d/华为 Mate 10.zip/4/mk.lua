Modulea = 591.0
Moduleb = 1047.0
Modulec = 464.0
Moduled = 272.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2