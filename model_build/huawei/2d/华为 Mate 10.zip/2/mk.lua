Modulea = 603.0
Moduleb = 1068.0
Modulec = 450.0
Moduled = 259.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2