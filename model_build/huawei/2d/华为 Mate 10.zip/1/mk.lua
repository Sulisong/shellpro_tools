Modulea = 592.0
Moduleb = 1060.0
Modulec = 456.0
Moduled = 262.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2