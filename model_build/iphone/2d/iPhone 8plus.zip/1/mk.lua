Modulea = 875.81015719468
Moduleb = 1551.9600967352
Modulec = 71.683192261185
Moduled = 220.48367593712
Modulew = 1040.0
Moduleh = 2026.0
Moduletype = 1