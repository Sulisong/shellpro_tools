Modulea = 644.70374848851
Moduleb = 1141.7654171705
Modulec = 72.108827085852
Moduled = 244.1015719468
Modulew = 784.0
Moduleh = 1628.0
Moduletype = 1