Modulea=1143.1354037267
Moduleb=2025.6596273292
Modulec=56.913043478261
Moduled=193.97763975155
Modulew=1254
Moduleh=2384
Moduletype=1
ModuleFillet = nil