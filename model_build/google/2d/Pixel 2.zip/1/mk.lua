Modulea = 815.48021162889
Moduleb = 1449.0291424482
Modulec = 132.25989418556
Moduled = 233.30011303819
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1