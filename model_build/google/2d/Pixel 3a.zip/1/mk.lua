Modulea=765.42236024845
Moduleb=1572.6583850932
Modulec=57.046583850932
Moduled=141.70186335404
Modulew=883
Moduleh=1870
Moduletype=1
ModuleFillet = nil