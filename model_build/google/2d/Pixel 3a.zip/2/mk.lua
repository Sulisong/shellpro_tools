Modulea=588.63354037267
Moduleb=1209.4658385093
Modulec=42.931677018634
Moduled=199.2298136646
Modulew=1080
Moduleh=1620
Moduletype=2
ModuleFillet = nil