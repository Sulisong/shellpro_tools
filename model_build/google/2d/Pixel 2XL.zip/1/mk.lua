Modulea=913.10434782609
Moduleb=1823.5465838509
Modulec=59.468322981366
Moduled=157.06459627329
Modulew=1056
Moduleh=2143
Moduletype=1
ModuleFillet = nil