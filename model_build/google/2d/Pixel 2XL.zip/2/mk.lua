Modulea = 929.45480813607
Moduleb = 1858.9096162721
Modulec = 76.476552937321
Moduled = 169.75793775542
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1