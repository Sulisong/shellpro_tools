Modulea = 854.00683580033
Moduleb = 1518.5911027577
Modulec = 114.0667661046
Moduled = 195.8436728715
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1