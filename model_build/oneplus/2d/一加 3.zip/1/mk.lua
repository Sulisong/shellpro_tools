Modulea = 873.86363636364
Moduleb = 1548.3253588517
Modulec = 102.5
Moduled = 178.18181818182
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1