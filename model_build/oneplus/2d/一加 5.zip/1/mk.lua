Modulea = 862.5
Moduleb = 1530.1435406699
Modulec = 104.77272727273
Moduled = 190.62200956938
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1