Modulea = 960.22727272727
Moduleb = 1906.1079545455
Modulec = 59.318181818182
Moduled = 128.86363636364
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1