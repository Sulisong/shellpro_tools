Modulea = 572.0
Moduleb = 1139.0
Modulec = 453.0
Moduled = 237.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2