Modulea = 820.60248447205
Moduleb = 1769.2422360248
Modulec = 41.116770186335
Moduled = 38.411180124224
Modulew = 904.0
Moduleh = 1874.0
Moduletype = 1