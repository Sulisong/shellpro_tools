Modulea = 1502.1714285714
Moduleb = 3242.4149068323
Modulec = 51.967701863354
Moduled = 65.311801242236
Modulew = 1604.0
Moduleh = 3392.0
Moduletype = 1
ModuleFillet = 3