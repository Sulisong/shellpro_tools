Modulea=955.2298136646
Moduleb=2070.1118012422
Modulec=33.385093167702
Moduled=38.906832298137
Modulew=1022
Moduleh=2160
Moduletype=1
ModuleFillet = 5