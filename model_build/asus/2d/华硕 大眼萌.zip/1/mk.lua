Modulea = 832.0
Moduleb = 1472.0
Modulec = 124.0
Moduled = 204.0
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1