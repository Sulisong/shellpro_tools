Modulea=628.88198757764
Moduleb=1261.7888198758
Modulec=162.67080745342
Moduled=134.83229813665
Modulew=1080.0
Moduleh=1620.0
Moduletype=3
ModuleFillet = nil