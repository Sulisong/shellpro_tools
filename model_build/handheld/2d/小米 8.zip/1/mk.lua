Modulea = 621.0
Moduleb = 1290.0
Modulec = 167.0
Moduled = 93.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 3