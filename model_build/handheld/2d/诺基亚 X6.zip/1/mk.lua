Modulea = 609.0
Moduleb = 1275.0
Modulec = 173.0
Moduled = 100.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 3