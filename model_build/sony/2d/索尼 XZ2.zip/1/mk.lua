Modulea = 534.0
Moduleb = 1064.0
Modulec = 498.0
Moduled = 250.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2