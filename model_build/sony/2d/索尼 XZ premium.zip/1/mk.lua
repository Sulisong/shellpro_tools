Modulea = 628.0
Moduleb = 1116.0
Modulec = 391.0
Moduled = 248.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2