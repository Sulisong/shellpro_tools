Modulea = 618.0
Moduleb = 1093.0
Modulec = 28.0
Moduled = 259.958
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2