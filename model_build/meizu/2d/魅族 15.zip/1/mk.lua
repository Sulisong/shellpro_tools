Modulea = 987.5
Moduleb = 1752.6315789474
Modulec = 99.0
Moduled = 165.47368421053
Modulew = 1188.0
Moduleh = 2112.0
Moduletype = 1