Modulea = 576.0
Moduleb = 1135.0
Modulec = 41.0
Moduled = 234.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2