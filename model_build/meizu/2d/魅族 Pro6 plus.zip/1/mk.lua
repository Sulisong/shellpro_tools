Modulea = 1101.5151515152
Moduleb = 2005.7416267943
Modulec = 170.0
Moduled = 257.99043062201
Modulew = 1440.0
Moduleh = 2560.0
Moduletype = 1