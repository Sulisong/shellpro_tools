Modulea = 1189.9428571429
Moduleb = 2460.7242236025
Modulec = 35.911801242236
Moduled = 72.754658385093
Modulew = 1265.0
Moduleh = 2603.0
Moduletype = 1