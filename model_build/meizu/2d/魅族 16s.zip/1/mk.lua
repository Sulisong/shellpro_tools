Modulea = 1188.2795031056
Moduleb = 2460.8571428571
Modulec = 36.428571428571
Moduled = 71.329192546584
Modulew = 1266.0
Moduleh = 2610.0
Moduletype = 1