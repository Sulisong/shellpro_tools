Modulea = 548.0
Moduleb = 1097.0
Modulec = 50.0
Moduled = 257.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2