Modulea = 590.0
Moduleb = 884.25
Modulec = 432.0
Moduled = 212.625
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2