Modulea = 1108.4720496894
Moduleb = 1959.5925465839
Modulec = 62.388198757764
Moduled = 241.84844720497
Modulew = 1241.0
Moduleh = 2496.0
Moduletype = 1