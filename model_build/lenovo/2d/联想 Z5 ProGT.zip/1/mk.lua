Modulea=964.51677018634
Moduleb=2070.9913043478
Modulec=21.078260869565
Moduled=21.227329192547
Modulew=1008
Moduleh=2136
Moduletype=1
ModuleFillet = 25