Modulea = 1388.5714285714
Moduleb = 2977.7142857143
Modulec = 42.928571428571
Moduled = 55.928571428571
Modulew = 1486.0
Moduleh = 3105.0
Moduletype = 1