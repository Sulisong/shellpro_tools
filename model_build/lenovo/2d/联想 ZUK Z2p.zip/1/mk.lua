Modulea = 839.77272727273
Moduleb = 1490.9090909091
Modulec = 124.09090909091
Moduled = 212.63157894737
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1