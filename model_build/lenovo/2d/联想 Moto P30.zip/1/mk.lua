Modulea = 1022.7801242236
Moduleb = 2117.4857142857
Modulec = 53.952173913043
Moduled = 69.048447204969
Modulew = 1135.0
Moduleh = 2316.0
Moduletype = 1