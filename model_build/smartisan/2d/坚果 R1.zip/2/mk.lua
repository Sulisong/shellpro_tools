Modulea = 1082.7515114873
Moduleb = 2243.377267231
Modulec = 78.873035066505
Moduled = 83.864570737606
Modulew = 1239.0
Moduleh = 2477.0
Moduletype = 1