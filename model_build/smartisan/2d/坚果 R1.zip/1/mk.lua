Modulea = 1162.0962962963
Moduleb = 2398.6444444444
Modulec = 72.833333333333
Moduled = 74.214814814815
Modulew = 1311.0
Moduleh = 2628.0
Moduletype = 1