Modulea = 816.0
Moduleb = 1446.6666666667
Modulec = 132.0
Moduled = 228.0
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1