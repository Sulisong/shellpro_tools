Modulea = 837.33333333333
Moduleb = 1486.6666666667
Modulec = 121.33333333333
Moduled = 204.0
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1