Modulea = 838.66666666667
Moduleb = 1486.6666666667
Modulec = 120.0
Moduled = 210.66666666667
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1