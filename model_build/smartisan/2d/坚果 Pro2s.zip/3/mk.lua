Modulea = 923.86363636364
Moduleb = 1851.6746411483
Modulec = 78.636363636364
Moduled = 150.93301435407
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1