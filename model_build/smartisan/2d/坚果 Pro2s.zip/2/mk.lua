Modulea = 1085.677146312
Moduleb = 2165.2720677146
Modulec = 62.140870616687
Moduled = 176.38452237001
Modulew = 1213.0
Moduleh = 2515.0
Moduletype = 1