Modulea = 1089.3591293833
Moduleb = 2169.576783555
Modulec = 67.011487303507
Moduled = 173.68802902056
Modulew = 1231.0
Moduleh = 2520.0
Moduletype = 1