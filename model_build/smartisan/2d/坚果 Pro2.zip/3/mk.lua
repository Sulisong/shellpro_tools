Modulea = 942.66666666667
Moduleb = 1882.6666666667
Modulec = 69.333333333333
Moduled = 132.0
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1