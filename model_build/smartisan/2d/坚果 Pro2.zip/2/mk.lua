Modulea = 937.33333333333
Moduleb = 1872.0
Modulec = 70.666666666667
Moduled = 137.33333333333
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1