Modulea = 948.0
Moduleb = 1893.3333333333
Modulec = 65.333333333333
Moduled = 122.66666666667
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1