Modulea = 948.86363636364
Moduleb = 1899.043062201
Modulec = 66.136363636364
Moduled = 132.63157894737
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1