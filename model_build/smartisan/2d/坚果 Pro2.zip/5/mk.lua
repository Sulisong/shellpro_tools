Modulea = 943.18181818182
Moduleb = 1887.2009569378
Modulec = 68.409090909091
Moduled = 129.4019138756
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1