Modulea = 860.0
Moduleb = 1528.75
Modulec = 105.0
Moduled = 186.25
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1