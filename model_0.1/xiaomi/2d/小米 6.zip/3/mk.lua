Modulea = 862.5
Moduleb = 1532.5
Modulec = 107.5
Moduled = 181.25
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1