Modulea = 875.0
Moduleb = 1555.023923445
Modulec = 104.77272727273
Moduled = 178.18181818182
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1