Modulea = 1135.8403869407
Moduleb = 2480.7013301088
Modulec = 62.408706166868
Moduled = 82.636033857316
Modulew = 1272.0
Moduleh = 2680.0
Moduletype = 1