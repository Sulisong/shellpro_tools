Modulea = 871.59090909091
Moduleb = 1543.5406698565
Modulec = 105.90909090909
Moduled = 171.48325358852
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1