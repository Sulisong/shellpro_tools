Modulea = 565.0
Moduleb = 1012.0
Modulec = 464.0
Moduled = 297.0
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2