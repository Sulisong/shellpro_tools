Modulea = 946.46916565901
Moduleb = 2047.146311971
Modulec = 67.472793228537
Moduled = 137.23095525998
Modulew = 1080.0
Moduleh = 2340.0
Moduletype = 1