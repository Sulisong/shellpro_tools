Modulea = 973.75
Moduleb = 1945.0
Modulec = 52.5
Moduled = 62.5
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1