Modulea = 950.0
Moduleb = 1898.2894736842
Modulec = 65.0
Moduled = 131.44736842105
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1