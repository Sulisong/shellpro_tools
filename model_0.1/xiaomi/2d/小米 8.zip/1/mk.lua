Modulea = 972.72727272727
Moduleb = 2022.3484848485
Modulec = 53.636363636364
Moduled = 79.563446969697
Modulew = 1080.0
Moduleh = 2248.0
Moduletype = 1