Modulea = 861.53846153846
Moduleb = 1531.2543312543
Modulec = 107.56756756757
Moduled = 186.27858627859
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1