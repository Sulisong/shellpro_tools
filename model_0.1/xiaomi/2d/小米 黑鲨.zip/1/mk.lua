Modulea = 915.0
Moduleb = 1828.75
Modulec = 83.75
Moduled = 152.5
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1