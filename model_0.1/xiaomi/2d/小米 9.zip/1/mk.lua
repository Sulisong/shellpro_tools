Modulea = 886.2652173913
Moduleb = 1908.0919254658
Modulec = 55.670186335404
Moduled = 66.501863354037
Modulew = 1004.0
Moduleh = 2059.0
Moduletype = 1