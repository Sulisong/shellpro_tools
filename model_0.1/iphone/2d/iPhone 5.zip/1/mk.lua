Modulea = 642.14026602177
Moduleb = 1139.0580411125
Modulec = 68.929866989117
Moduled = 233.14631197098
Modulew = 780.0
Moduleh = 1634.0
Moduletype = 1