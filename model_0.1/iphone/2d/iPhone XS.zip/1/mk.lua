Modulea = 1124.4860943168
Moduleb = 2436.9220072551
Modulec = 85.256952841596
Moduled = 77.10761789601
Modulew = 1295.0
Moduleh = 2657.0
Moduletype = 1