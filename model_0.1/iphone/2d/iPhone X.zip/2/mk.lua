Modulea = 550.0
Moduleb = 1179.0
Modulec = 484.0
Moduled = 203.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2