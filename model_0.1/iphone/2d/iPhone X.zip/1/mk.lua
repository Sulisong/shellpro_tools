Modulea = 885.85679012346
Moduleb = 1916.3950617284
Modulec = 69.802469135802
Moduled = 62.533333333333
Modulew = 1028.0
Moduleh = 2044.0
Moduletype = 1