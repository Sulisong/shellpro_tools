Modulea = 641.44135429262
Moduleb = 960.81257557437
Modulec = 61.729141475212
Moduled = 264.49334945586
Modulew = 764.0
Moduleh = 1488.0
Moduletype = 1