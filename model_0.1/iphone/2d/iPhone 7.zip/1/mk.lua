Modulea = 759.78234582829
Moduleb = 1347.3760580411
Modulec = 72.261185006046
Moduled = 209.85489721886
Modulew = 900.0
Moduleh = 1780.0
Moduletype = 1