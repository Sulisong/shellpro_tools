Modulea = 636.0
Moduleb = 1120.0
Modulec = 29.0
Moduled = 248.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2