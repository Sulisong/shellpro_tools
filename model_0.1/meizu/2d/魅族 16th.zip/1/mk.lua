Modulea = 559.0
Moduleb = 1123.0
Modulec = 492.0
Moduled = 239.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2