Modulea = 583.0
Moduleb = 1144.0
Modulec = 462.0
Moduled = 228.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2