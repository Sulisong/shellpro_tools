Modulea = 836.36363636364
Moduleb = 1484.2105263158
Modulec = 120.68181818182
Moduled = 209.76076555024
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1