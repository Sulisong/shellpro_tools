Modulea = 1397.1366459627
Moduleb = 2796.2273291925
Modulec = 72.500621118012
Moduled = 171.95527950311
Modulew = 1548.0
Moduleh = 3146.0
Moduletype = 1