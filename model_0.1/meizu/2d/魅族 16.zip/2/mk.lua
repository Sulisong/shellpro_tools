Modulea = 968.18181818182
Moduleb = 1946.4114832536
Modulec = 53.636363636364
Moduled = 103.56459330144
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1