Modulea = 963.63636363636
Moduleb = 1927.033492823
Modulec = 57.045454545455
Moduled = 115.40669856459
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1