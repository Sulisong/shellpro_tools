Modulea = 853.40909090909
Moduleb = 1508.1339712919
Modulec = 111.59090909091
Moduled = 200.19138755981
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1