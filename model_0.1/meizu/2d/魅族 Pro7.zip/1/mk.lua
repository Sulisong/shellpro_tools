Modulea = 675.0
Moduleb = 1202.0
Modulec = 362.0
Moduled = 188.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2