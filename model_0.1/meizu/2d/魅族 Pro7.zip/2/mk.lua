Modulea = 843.18181818182
Moduleb = 1495.6937799043
Modulec = 117.27272727273
Moduled = 205.93301435407
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1