Modulea = 590.0
Moduleb = 1185.0
Modulec = 34.0
Moduled = 214.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2