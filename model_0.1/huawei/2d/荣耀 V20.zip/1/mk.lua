Modulea = 1402.6583850932
Moduleb = 2990.4596273292
Modulec = 94.639751552795
Moduled = 98.608695652174
Modulew = 1602.0
Moduleh = 3240.0
Moduletype = 1