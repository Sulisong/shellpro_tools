Modulea = 580.58385093168
Moduleb = 1237.6397515528
Modulec = 463.52795031056
Moduled = 181.11801242236
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2