Modulea = 702.33540372671
Moduleb = 1510.3229813665
Modulec = 42.819875776398
Moduled = 49.304347826087
Modulew = 792.0
Moduleh = 1620.0
Moduletype = 1