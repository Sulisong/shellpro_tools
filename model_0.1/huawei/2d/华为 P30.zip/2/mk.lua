Modulea = 538.32298136646
Moduleb = 1158.149068323
Modulec = 508.80745341615
Moduled = 227.40372670807
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2