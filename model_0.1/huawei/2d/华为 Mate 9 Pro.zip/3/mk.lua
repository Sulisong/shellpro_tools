Modulea = 603.0
Moduleb = 1071.0
Modulec = 447.0
Moduled = 277.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2