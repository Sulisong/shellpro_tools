Modulea = 596.0
Moduleb = 1062.0
Modulec = 452.0
Moduled = 276.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2