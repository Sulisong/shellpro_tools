Modulea = 602.0
Moduleb = 1067.0
Modulec = 446.0
Moduled = 279.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2