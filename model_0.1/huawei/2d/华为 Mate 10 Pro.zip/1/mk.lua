Modulea = 554.0
Moduleb = 1107.0
Modulec = 499.0
Moduled = 258.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2