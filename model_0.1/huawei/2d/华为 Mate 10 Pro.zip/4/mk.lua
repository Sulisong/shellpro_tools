Modulea = 551.0
Moduleb = 1109.0
Modulec = 500.0
Moduled = 245.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2