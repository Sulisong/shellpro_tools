Modulea = 549.0
Moduleb = 1103.0
Modulec = 501.0
Moduled = 252.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2