Modulea = 549.0
Moduleb = 1102.0
Modulec = 502.0
Moduled = 266.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2