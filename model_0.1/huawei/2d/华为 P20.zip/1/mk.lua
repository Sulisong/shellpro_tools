Modulea = 982.95454545455
Moduleb = 2025.4605263158
Modulec = 44.545454545455
Moduled = 55.026315789474
Modulew = 1080.0
Moduleh = 2244.0
Moduletype = 1