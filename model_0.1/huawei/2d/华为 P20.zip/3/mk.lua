Modulea = 660.0
Moduleb = 1357.0
Modulec = 382.0
Moduled = 97.958
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2