Modulea = 964.0
Moduleb = 2002.6666666667
Modulec = 62.666666666667
Moduled = 71.333333333333
Modulew = 1080.0
Moduleh = 2244.0
Moduletype = 1