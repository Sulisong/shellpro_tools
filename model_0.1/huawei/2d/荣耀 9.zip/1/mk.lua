Modulea = 845.0
Moduleb = 1493.6842105263
Modulec = 116.25
Moduled = 213.68421052632
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1