Modulea = 542.34782608696
Moduleb = 1161.1677018634
Modulec = 517.86335403727
Moduled = 222.37267080745
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2