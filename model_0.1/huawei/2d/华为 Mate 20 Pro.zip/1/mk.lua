Modulea = 1022.5
Moduleb = 2203
Modulec = 26
Moduled = 55
Modulew = 1080.0
Moduleh = 2340.0
Moduletype = 1