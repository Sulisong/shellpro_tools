Modulea = 968.75
Moduleb = 2018.9473684211
Modulec = 52.5
Moduled = 52.80701754386
Modulew = 1080.0
Moduleh = 2240.0
Moduletype = 1