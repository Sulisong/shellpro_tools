Modulea = 595.0
Moduleb = 1244.0
Modulec = 446.0
Moduled = 158.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2