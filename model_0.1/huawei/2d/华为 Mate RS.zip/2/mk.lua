Modulea = 611.0
Moduleb = 1237.0
Modulec = 441.0
Moduled = 187.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2