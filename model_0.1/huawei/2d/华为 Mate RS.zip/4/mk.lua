Modulea = 608.0
Moduleb = 1209.0
Modulec = 446.0
Moduled = 211.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2