Modulea = 1256.6666666667
Moduleb = 2498.3333333333
Modulec = 93.333333333333
Moduled = 188.33333333333
Modulew = 1440.0
Moduleh = 2880.0
Moduletype = 1