Modulea = 590.0
Moduleb = 1192.0
Modulec = 459.0
Moduled = 208.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2