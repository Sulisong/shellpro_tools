Modulea = 567.0
Moduleb = 1232.0
Modulec = 475.0
Moduled = 179.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2