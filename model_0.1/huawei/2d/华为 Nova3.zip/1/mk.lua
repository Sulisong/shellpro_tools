Modulea = 592.0
Moduleb = 1288.0
Modulec = 448.0
Moduled = 161.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2