Modulea = 988.11426889711
Moduleb = 2063.7829666838
Modulec = 47.193643107012
Moduled = 86.303651334051
Modulew = 1080.0
Moduleh = 2244.0
Moduletype = 1