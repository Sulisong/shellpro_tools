Modulea = 563.47826086957
Moduleb = 1165.1925465839
Modulec = 490.69565217391
Moduled = 217.34161490683
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2