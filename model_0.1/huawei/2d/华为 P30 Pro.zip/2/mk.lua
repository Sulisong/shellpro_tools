Modulea = 556.4347826087
Moduleb = 1182.298136646
Modulec = 503.77639751553
Moduled = 215.32919254658
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2
ModuleFillet = 50