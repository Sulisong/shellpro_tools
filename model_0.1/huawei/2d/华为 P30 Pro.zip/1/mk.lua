Modulea = 1446.9316770186
Moduleb = 3054.8571428571
Modulec = 50.003105590062
Moduled = 78.484472049689
Modulew = 1557.0
Moduleh = 3240.0
Moduletype = 1
ModuleFillet = 50