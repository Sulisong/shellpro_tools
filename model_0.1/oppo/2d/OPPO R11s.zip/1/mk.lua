Modulea = 950.0
Moduleb = 1905.5023923445
Modulec = 66.136363636364
Moduled = 122.94258373206
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1