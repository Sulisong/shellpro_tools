Modulea = 621.0
Moduleb = 1335.0
Modulec = 422.0
Moduled = 123.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2