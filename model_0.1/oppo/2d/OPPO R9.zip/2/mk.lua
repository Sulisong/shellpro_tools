Modulea = 629.0
Moduleb = 1114.0
Modulec = 420.0
Moduled = 246.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2