Modulea = 870.45454545455
Moduleb = 1539.7129186603
Modulec = 102.5
Moduled = 187.75119617225
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1