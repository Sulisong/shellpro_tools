Modulea=869.36645962733
Moduleb=1536.0
Modulec=103.52795031056
Moduled=189.6149068323
Modulew=1080
Moduleh=1920
Moduletype=1
ModuleFillet = nil