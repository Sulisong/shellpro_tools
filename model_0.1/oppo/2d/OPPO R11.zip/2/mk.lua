Modulea = 546.0
Moduleb = 971.0
Modulec = 498.0
Moduled = 322.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2