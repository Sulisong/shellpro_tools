Modulea = 658.0
Moduleb = 1381.0
Modulec = 372.0
Moduled = 170.042
Modulew = 1080.0
Moduleh = 1620
Moduletype = 2