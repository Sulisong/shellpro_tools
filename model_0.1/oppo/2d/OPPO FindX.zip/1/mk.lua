Modulea = 647.0
Moduleb = 1383.0
Modulec = 409.0
Moduled = 150.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2