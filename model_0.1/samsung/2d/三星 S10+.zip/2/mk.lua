Modulea = 570.52173913043
Moduleb = 1188.3354037267
Modulec = 495.72670807453
Moduled = 209.29192546584
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2
ModuleFillet = 50