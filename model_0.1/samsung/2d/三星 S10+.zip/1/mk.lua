Modulea = 1065.3540372671
Moduleb = 2229.5403726708
Modulec = 25.549689440994
Moduled = 47.962732919255
Modulew = 1115.0
Moduleh = 2340.0
Moduletype = 1
ModuleFillet = 50