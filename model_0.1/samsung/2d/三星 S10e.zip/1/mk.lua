Modulea = 1029.7888198758
Moduleb = 2156.298136646
Modulec = 58.295031055901
Moduled = 55.472049689441
Modulew = 1135.0
Moduleh = 2290.0
Moduletype = 1
ModuleFillet = 50