Modulea = 563.47826086957
Moduleb = 1179.2795031056
Modulec = 487.67701863354
Moduled = 212.31055900621
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2
ModuleFillet = 50