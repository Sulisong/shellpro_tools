Modulea=567.50310559006
Moduleb=1164.1863354037
Modulec=497.73913043478
Moduled=227.40372670807
Modulew=1080
Moduleh=1620
Moduletype=2
ModuleFillet = nil