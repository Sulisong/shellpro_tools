Modulea=795.45590062112
Moduleb=1637.1068322981
Modulec=26.025465838509
Moduled=90.136645962733
Modulew=843
Moduleh=1814
Moduletype=1
ModuleFillet = nil