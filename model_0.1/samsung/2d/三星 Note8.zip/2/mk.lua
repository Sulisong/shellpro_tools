Modulea=793.20248447205
Moduleb=1634.8534161491
Modulec=26.080745341615
Moduled=92.390062111801
Modulew=1100
Moduleh=1814
Moduletype=1
ModuleFillet = nil