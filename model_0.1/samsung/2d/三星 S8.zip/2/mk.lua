Modulea=1142.8881987578
Moduleb=2342.5155279503
Modulec=39.245341614907
Moduled=145.90062111801
Modulew=1223
Moduleh=2610
Moduletype=1
ModuleFillet = nil