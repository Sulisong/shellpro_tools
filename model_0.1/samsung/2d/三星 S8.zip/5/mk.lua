Modulea=602.72049689441
Moduleb=1233.6149068323
Modulec=18.782608695652
Moduled=197.21739130435
Modulew=1080
Moduleh=1620
Moduletype=2
ModuleFillet = nil