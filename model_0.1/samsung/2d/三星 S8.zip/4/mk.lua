Modulea=1043.5838509317
Moduleb=2140.6086956522
Modulec=34.450310559006
Moduled=132.11801242236
Modulew=1111
Moduleh=2390
Moduletype=1
ModuleFillet = nil