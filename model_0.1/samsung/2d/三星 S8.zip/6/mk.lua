Modulea=632.90683229814
Moduleb=1298.0124223602
Modulec=67.080745341615
Moduled=196.21118012422
Modulew=1080
Moduleh=1620
Moduletype=2
ModuleFillet = nil