Modulea=1142.8881987578
Moduleb=2344.1366459627
Modulec=39.245341614907
Moduled=142.65838509317
Modulew=1223
Moduleh=2610
Moduletype=1
ModuleFillet = nil