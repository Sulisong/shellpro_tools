Modulea=898.12173913043
Moduleb=1957.747826087
Modulec=40.313043478261
Moduled=49.895652173913
Modulew=984
Moduleh=2114
Moduletype=1
ModuleFillet = nil