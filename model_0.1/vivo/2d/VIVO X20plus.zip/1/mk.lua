Modulea = 642.0
Moduleb = 1251.0
Modulec = 392.0
Moduled = 182.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2