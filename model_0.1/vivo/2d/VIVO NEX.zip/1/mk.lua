Modulea = 922.33684210526
Moduleb = 1961.150877193
Modulec = 78.154385964912
Moduled = 138.14736842105
Modulew = 1080.0
Moduleh = 2316.0
Moduletype = 1