Modulea = 921.33333333333
Moduleb = 1840.0
Modulec = 74.666666666667
Moduled = 162.66666666667
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1