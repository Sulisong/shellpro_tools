Modulea = 937.33333333333
Moduleb = 1873.3333333333
Modulec = 70.666666666667
Moduled = 138.66666666667
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1