Modulea=1082.8105590062
Moduleb=1919.0248447205
Modulec=76.642857142857
Moduled=290.85714285714
Modulew=1244
Moduleh=2545
Moduletype=1
ModuleFillet = nil