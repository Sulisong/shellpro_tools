Modulea=1082.8105590062
Moduleb=1925.347826087
Modulec=78.223602484472
Moduled=287.69565217391
Modulew=1244
Moduleh=2545
Moduletype=1
ModuleFillet = nil