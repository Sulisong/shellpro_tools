Modulea = 1118.552173913
Moduleb = 2219.552173913
Modulec = 48.734782608696
Moduled = 178.71304347826
Modulew = 1224.0
Moduleh = 2569.0
Moduletype = 1