Modulea = 895.9112959113
Moduleb = 1590.0207900208
Modulec = 88.717948717949
Moduled = 162.99376299376
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1