Modulea=1066.2782608696
Moduleb=2494.6260869565
Modulec=61.878260869565
Moduled=64.773913043478
Modulew=1200
Moduleh=2674
Moduletype=1
ModuleFillet = nil