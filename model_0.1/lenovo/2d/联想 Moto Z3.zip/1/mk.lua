Modulea = 1007.9428571429
Moduleb = 2005.9900621118
Modulec = 59.735403726708
Moduled = 124.40248447205
Modulew = 1126.0
Moduleh = 2276.0
Moduletype = 1