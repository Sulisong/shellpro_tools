Modulea=886.66583850932
Moduleb=1912.7776397516
Modulec=23.351552795031
Moduled=167.07204968944
Modulew=936
Moduleh=2118
Moduletype=1
ModuleFillet = 25