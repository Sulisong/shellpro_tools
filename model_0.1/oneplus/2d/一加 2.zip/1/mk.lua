Modulea = 880.0
Moduleb = 1562.6666666667
Modulec = 100.0
Moduled = 168.0
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1