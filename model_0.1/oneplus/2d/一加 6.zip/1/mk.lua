Modulea = 1283.5555555556
Moduleb = 2704.0
Modulec = 76.444444444444
Moduled = 136.88888888889
Modulew = 1440.0
Moduleh = 3040.0
Moduletype = 1