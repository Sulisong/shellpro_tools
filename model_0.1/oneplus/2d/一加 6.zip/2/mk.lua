Modulea = 1278.7227353903
Moduleb = 2691.2652919261
Modulec = 59.334439190138
Moduled = 105.73417967052
Modulew = 1404.0
Moduleh = 2964.0
Moduletype = 1