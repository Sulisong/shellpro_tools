Modulea = 574.0
Moduleb = 1207.0
Modulec = 456.0
Moduled = 193.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2