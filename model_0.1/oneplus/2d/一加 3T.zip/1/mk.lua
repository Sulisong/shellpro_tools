Modulea = 861.36363636364
Moduleb = 1531.1004784689
Modulec = 110.45454545455
Moduled = 187.75119617225
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1