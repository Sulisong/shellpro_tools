Modulea = 1082.4248447205
Moduleb = 1926.449689441
Modulec = 62.970186335404
Moduled = 213.22732919255
Modulew = 1198.0
Moduleh = 2384.0
Moduletype = 1