Modulea = 845.33333333333
Moduleb = 1502.6666666667
Modulec = 117.33333333333
Moduled = 174.66666666667
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1