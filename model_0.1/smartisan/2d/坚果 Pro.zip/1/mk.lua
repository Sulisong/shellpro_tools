Modulea = 848.0
Moduleb = 1505.3333333333
Modulec = 116.0
Moduled = 172.0
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1