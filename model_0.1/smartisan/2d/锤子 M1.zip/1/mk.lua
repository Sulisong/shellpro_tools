Modulea = 842.66666666667
Moduleb = 1497.3333333333
Modulec = 118.66666666667
Moduled = 204.0
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1