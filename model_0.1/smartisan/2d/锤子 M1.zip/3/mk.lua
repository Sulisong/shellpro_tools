Modulea = 841.33333333333
Moduleb = 1493.3333333333
Modulec = 120.0
Moduled = 208.0
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1