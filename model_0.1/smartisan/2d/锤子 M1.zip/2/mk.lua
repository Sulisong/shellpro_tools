Modulea = 844.0
Moduleb = 1496.0
Modulec = 117.33333333333
Moduled = 208.0
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1