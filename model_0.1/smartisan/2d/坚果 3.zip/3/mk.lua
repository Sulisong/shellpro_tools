Modulea = 1082.4159613059
Moduleb = 2166.322853688
Modulec = 65.801088270859
Moduled = 64.110036275695
Modulew = 1217.0
Moduleh = 2466.0
Moduletype = 1