Modulea = 1082.5882708585
Moduleb = 2166.6656590085
Modulec = 64.950423216445
Moduled = 64.032043530834
Modulew = 1211.0
Moduleh = 2463.0
Moduletype = 1