Modulea = 1085.7466747279
Moduleb = 2168.4981862152
Modulec = 61.375453446191
Moduled = 70.386336154776
Modulew = 1207.0
Moduleh = 2477.0
Moduletype = 1