Modulea = 1312.7593712213
Moduleb = 3061.0411124547
Modulec = 117.7484885127
Moduled = 198.15235792019
Modulew = 1540.0
Moduleh = 3414.0
Moduletype = 1