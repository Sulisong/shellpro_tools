Modulea=1101.0385093168
Moduleb=1964.3527950311
Modulec=76.224844720497
Moduled=256.49192546584
Modulew=1266
Moduleh=2518
Moduletype=1
ModuleFillet = nil