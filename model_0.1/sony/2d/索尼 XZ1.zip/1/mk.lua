Modulea = 825.11186767175
Moduleb = 1461.8713505053
Modulec = 129.04934217127
Moduled = 235.44048104771
Modulew = 1080.0
Moduleh = 1920.0
Moduletype = 1