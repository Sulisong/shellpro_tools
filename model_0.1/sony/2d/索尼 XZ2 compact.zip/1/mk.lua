Modulea = 894.5400549807
Moduleb = 1783.0603249346
Modulec = 93.331951012327
Moduled = 179.38959379828
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1