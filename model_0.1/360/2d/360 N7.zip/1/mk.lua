Modulea = 925.0
Moduleb = 1845.0
Modulec = 75.0
Moduled = 156.25
Modulew = 1080.0
Moduleh = 2160.0
Moduletype = 1