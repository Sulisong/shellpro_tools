Modulea = 967.78077280662
Moduleb = 2099.9016768446
Modulec = 56.109613596688
Moduled = 96.517219929502
Modulew = 1080.0
Moduleh = 2340.0
Moduletype = 1