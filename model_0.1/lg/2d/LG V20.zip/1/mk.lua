Modulea = 1163.6363636364
Moduleb = 2059.3301435407
Modulec = 136.66666666667
Moduled = 275.85326953748
Modulew = 1440.0
Moduleh = 2560.0
Moduletype = 1