Modulea = 608.0
Moduleb = 1081.0
Modulec = 175.0
Moduled = 240.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 3