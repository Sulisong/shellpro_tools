Modulea = 588.0
Moduleb = 1174.0
Modulec = 143.0
Moduled = 200.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 3