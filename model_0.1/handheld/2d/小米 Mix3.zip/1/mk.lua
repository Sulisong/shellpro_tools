Modulea = 612.0
Moduleb = 1327.0
Modulec = 232.0
Moduled = 169.0
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 3