Modulea = 627.0
Moduleb = 1243.0
Modulec = 163.0
Moduled = 130.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 3