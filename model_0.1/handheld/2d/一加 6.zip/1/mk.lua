Modulea = 615.0
Moduleb = 1290.0
Modulec = 169.0
Moduled = 102.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 3