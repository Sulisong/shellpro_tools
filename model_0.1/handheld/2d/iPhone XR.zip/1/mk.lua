Modulea=597.68944099379
Moduleb=1305.0559006211
Modulec=230.08695652174
Moduled=221.36645962733
Modulew=1080
Moduleh=1620
Moduletype=3
ModuleFillet = nil