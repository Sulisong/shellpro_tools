Modulea = 598.0
Moduleb = 1226.0
Modulec = 139.0
Moduled = 162.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 3