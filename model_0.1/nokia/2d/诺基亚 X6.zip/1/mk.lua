Modulea = 972.5
Moduleb = 2036.25
Modulec = 56.25
Moduled = 90.0
Modulew = 1080.0
Moduleh = 2280.0
Moduletype = 1