Modulea = 693.0
Moduleb = 1384.0
Modulec = 323.0
Moduled = 117.958
Modulew = 1080.0
Moduleh = 1620.0
Moduletype = 2