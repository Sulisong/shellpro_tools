Modulea = 1210.6734006734
Moduleb = 2356.0606060606
Modulec = 45.83164983165
Moduled = 37.575757575758
Modulew = 1312.0
Moduleh = 2560.0
Moduletype = 1